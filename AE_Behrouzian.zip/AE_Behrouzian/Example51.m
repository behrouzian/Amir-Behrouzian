%Author: Amir Behrouzian (abehrouzian@gmail.com)
%Example V.1
%OUTPUT: Fig.2 of the paper: Firmness Analysis of Real-Time Applications
%Under Static-Priority Preemptive Scheduling
%
clear;clc
%%%% INPUT
k=10;         %Number of the consecutive jobs
C=[2,3,1.5];  %Execution times in priority order [higher priority>>>lower priority]
D=[3,7,11];   %Deadlines of the tasks in priority order [higher priority>>>lower priority]
T=[6,8,13];   %Period in priority order [higher priority>>>lower priority]
O=[0,4];      %Offsets of each task in priority order [higher priority>>>lower priority]. There is no offset decided for the lowest priority task
step=0.01;    %Accuracy of the solution using time discritization


%------------------------------------------------------------------------------------------------


%%FAn method: phase1: hit-zone formulation

%obtain the accessibility function (paper: Definition.1)
SizeC=size(C);
Nht=SizeC(1,2)-1; %(Number of higher priority tasks)number of tasks with priorities higher that the lowest priority task
tic
%calculation of the hiperperiod of tasks with higher priority
H=1;
for i=1:(SizeC(1,2)-1);
    H=lcm(H,T(1,i));
end

%obtain accessibility function
l=zeros(1,H*(1/step));  % l: accessibility function
numjobinfirsthype=0; %number of the jobs in the first hyperperiod
loopcounter=0;
for n=1:Nht
    Numjobfirsthyp=H/T(1,n);
    Nhtloc=n-1;
    
    for i=1:Numjobfirsthyp
        B=O(1,n)+(i-1)*T(1,n); % B: commencement of a job execution
        numjobinfirsthype=numjobinfirsthype+1; %counter for the number of jobs in total in the first hyperperiod
        %%% calculation of idle till B
        Idle=0;
        for nn=1:B*(1/step)
            if l(1,nn)==0
                Idle=Idle+1;
            end
        end
        Idle=Idle*step;
        
        
        %%% calculation of the response time of the job i of task n
        Con=i*C(1,n)+Idle;
        tnew=Con;    % pronounce it t-old
        told=tnew+1;  %pronounce it t-new
        f=0;  %initialization
        while told~=tnew;
            told=tnew;
            f=0;
            if Nhtloc>0
                for m=1:Nhtloc
                f=f+ceil(((told-O(1,m))/T(1,m)))*C(1,m);
                loopcounter=loopcounter+1;
                end
            end
            tnew=Con+f;
        end
        R=tnew;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        for nnn=1:H*(1/step)
            if B <= (nnn*step) & (nnn*step)<=R
                l(1,nnn)=1;
            end
        end
        
    end
end
l=1-l;
atfstart2=zeros(1,100);
atfend2=zeros(1,100);
atfstart_counter=0;
atfend_counter=0;
%examine if the begining of a period is atfstart. 
if l(1,1)>l(1,H*(1/step))
    atfstart_counter=atfstart_counter+1;
    atfstart2(1,atfstart_counter)=0;
end
%examine the rest of a period to find atfstart and end
for n=1:(H*(1/step)-1)
    if l(1,n)<l(1,n+1)
        atfstart_counter=atfstart_counter+1;
        atfstart2(1,atfstart_counter)=n*step;
    end
    if l(1,n)>l(1,n+1)
        atfend_counter=atfend_counter+1;
        atfend2(1,atfend_counter)=n*step;
    end
end
%examine if the end of a period is atfend. 
if l(1,1)<l(1,H*(1/step))
    atfend_counter=atfend_counter+1;
    atfend2(1,atfend_counter)=H;
end
atfstart=zeros(1,atfstart_counter);
atfend=zeros(1,atfstart_counter);
for n=1:atfstart_counter
    atfstart(1,n)=atfstart2(1,n);
    atfend(1,n)=atfend2(1,n);
end
toc



%% SOLUTION WITH DISCRITIZATION

SizeT=size(T);
SizeD=size(D);
Ti=T(1,SizeT(1,2));          %sampling period of the task with lower priority
Di=D(1,SizeD(1,2));
Ci=C(1,SizeC(1,2));        %execution time of the the task with lower priority


sizetdmaschedule=size(atfstart);


atf=zeros(1,((k*Ti))*(1/step));
for j=1:sizetdmaschedule(1,2);
    for i=1:((k*Ti))*(1/step);
        if (mod((i-1)*step,H)>=atfstart(1,j) && mod((i-1)*step,H)<(atfend(1,j)))
        atf(1,i)=1;
        end
    end
end

raf=zeros(1,((k*Ti)/step));
for i=1:1:(k*Ti)/step;
    for j=0:1:Di/step;
        mm=i+j;
        if mm>=(k*Ti)*(1/step)-mod((k*Ti),H)*(1/step)+1;  %once mm reaches to the last time wheel in atf which is partialy generated
            mm=mm-((k*Ti)*(1/step)-mod((k*Ti),H)*(1/step));
        end
        raf(1,i)=raf(1,i)+atf(1,mm);
    end
end
raf=raf*step;

hitzf=ones(1,((k*Ti)/step));
for i=1:1:(k*Ti)/step;
    if Ci<raf(1,i);
        hitzf(1,i)=0;
    end
end


%report the start and end time of the hit zones
hzstarttime2=zeros(1,100);
hzendtime2=zeros(1,100);
hzstarttime_counter=0;
hzendtime_counter=0;
for i=2:1:(k*Ti)/step;
    if hitzf(1,i)<hitzf(1,i-1) && i*step<H; %note that we want to find the begining of HIT-ZONE
        hzstarttime_counter=hzstarttime_counter+1;
        hzstarttime2(1,hzstarttime_counter)=(i-1)*step;
    elseif hitzf(1,i)>hitzf(1,i-1)&& i*step<H;
        hzendtime_counter=hzendtime_counter+1;
        hzendtime2(1,hzendtime_counter)=(i-1)*step;
    end
end
hzstarttime=zeros(1,hzstarttime_counter);
hzendtime=zeros(1,hzendtime_counter);
for i=1:1:hzstarttime_counter;
    hzstarttime(1,i) = hzstarttime2(1,i);
    hzendtime(1,i) = hzendtime2(1,i);
end

%--------------------------------------------------------

% csdf is the position of the releases of $\tau_i$ when the first release time (the offset) is zero
csdf=zeros(1,k*Ti*(1/step));
for i=1:k*Ti*(1/step);
    if mod((i-1)*step,Ti)==0;
        csdf(1,i)=1;
    end
end


%here we determine the number of DM for an offset of ii-1 of the window of
%k release of $\tau_i$ in dimention 2 (to right)
integerization1=H*(1/step)-mod(H*(1/step),1); %integerization!!! infact integerization1=w*(1/step
dmsno=zeros(1,integerization1);
ii=0;
for i=0:step:H-step;
    ii=ii+1;
    dmsno(1,ii)=sum(circshift(csdf,ii-1,2).*hitzf);    
end







%%FAn method: phase2: compute m1-max(k)
%%%%%%determining the first sample position when one of the sample hit the
%begigning of a miss zone
mzstarttimesize=size(hzstarttime);
mzstarttimeno=mzstarttimesize(1,2);
firstsampleposition=zeros(1,k*mzstarttimeno);
dmsmaxsuspicion=zeros(1,mzstarttimeno*k);
for j=1:mzstarttimeno
    for i=1:k
        firstsampleposition(1,(j-1)*k+i)=mod(hzstarttime(1,j),H)-mod((i-1)*Ti,H);
        if firstsampleposition(1,(j-1)*k+i)<0
            firstsampleposition(1,(j-1)*k+i)=H+firstsampleposition(1,(j-1)*k+i);
        end
        if firstsampleposition(1,(j-1)*k+i)==0 
            dmsmaxsuspicion(1,(j-1)*k+i)=dmsno(1,1); % because the first element is dmsno(1,1)
        else
        dmsmaxsuspicion(1,(j-1)*k+i)=dmsno(1,floor(firstsampleposition(1,(j-1)*k+i)/step));
        end
    end
end

DSMAX=max(dmsmaxsuspicion);
yaxisfirstsampleposition=max(dmsno)*ones(1,k*mzstarttimeno);
yaxisfirstsampleposition=k-yaxisfirstsampleposition;
%---------------------------------------------------------------------------

%%%%%%%%%Obtaining the maximum number of deadline misses
DSMAXtest=max(dmsno);
%---------------------------------------------------------------------------

%here we obtain the candidate for the minimum number of DMs
mzendtimesize=size(hzendtime);
mzendtimeno=mzendtimesize(1,2);
firstsamplepositionformindm=zeros(1,k*mzendtimeno);
dmsminsuspicion=zeros(1,mzendtimeno*k);
for j=1:mzendtimeno
    for i=1:k
        firstsamplepositionformindm(1,(j-1)*k+i)=mod(hzendtime(1,j),H)-mod((i-1)*Ti,H);
        if firstsamplepositionformindm(1,(j-1)*k+i)<0
            firstsamplepositionformindm(1,(j-1)*k+i)=H+firstsamplepositionformindm(1,(j-1)*k+i);
        end
        if firstsamplepositionformindm(1,(j-1)*k+i)==0 
            dmsminsuspicion(1,(j-1)*k+i)=dmsno(1,1); % because the first element is dmsno(1,1)
        else
        dmsminsuspicion(1,(j-1)*k+i)=dmsno(1,floor(firstsamplepositionformindm(1,(j-1)*k+i)/step));
        end
    end
end
DSMIN=min(dmsminsuspicion);
yaxisfirstsamplepositionformindm=max(dmsno)*ones(1,k*mzendtimeno);
yaxisfirstsamplepositionformindm=k-yaxisfirstsamplepositionformindm;
%---------------------------------------------------------------------------








%PLOT: creating a unique x axis for all plots
plotuntil=H; %this define the range of the plots except the plot of DHs numbers
tplot=0:step:plotuntil-step;
tsize=size(tplot);
tnumber=tsize(1,2);

%equalizing the size of the y axises and x axis for plotting


atfplot=zeros(1,tnumber);
for i=1:1:plotuntil/step;
atfplot(1,i)=atf(1,i);
end

rafplot=zeros(1,tnumber);
for i=1:1:plotuntil/step;
rafplot(1,i)=raf(1,i);
end

eplot=zeros(1,tnumber);
for i=1:1:plotuntil/step;
eplot(1,i)=Ci;
end

misszfplot=zeros(1,tnumber);
for i=1:1:plotuntil/step;
misszfplot(1,i)=hitzf(1,i);
end
hitzfplot=1-misszfplot;

tdmsplot=0:step:H-step;
tdmssize=size(tdmsplot);
tdmsnumber=tdmssize(1,2);
dmsnoplot=zeros(1,tdmsnumber);
for i=1:1:H/step;   %dmsno will be plotted only for first time wheel
dmsnoplot(1,i)=dmsno(1,i);
end

%---------------------number of DH
dhsnoplot=k-dmsnoplot;

%-------------------------------


csdfplot=zeros(1,tnumber);
for i=1:1:plotuntil/step;
csdfplot(1,i)=csdf(1,i);
end


%figure function
figure;
%%
%first plot
ax1=subplot(4,1,1);
plot(ax1,tplot,atfplot,'.','linewidth',0.8);
hold on
hold off
set(gca, 'FontName', 'times')
set(gca,'XTick',[0:4:H])
xlabel({'time (\times100us)';'(b)'});
ylabel(['l_' num2str('1') '(t)'])
axis([0,plotuntil,-0.1,1.1]);
%%
%second plot
ax2=subplot(4,1,2);
plot(ax2,tplot,rafplot,tplot,eplot,'--','linewidth',0.9);
set(gca, 'FontName', 'times')
set(gca,'XTick',[0:4:H])
xlabel({'time (\times100us)';'(c)'});
ylabel(['g_' num2str('1') '(t) (\times100us)'])
grid on
axis([0,plotuntil,0,3]);
axis 'auto y'
annotationx = [0.17,0.2]; 
annotationy = [0.643,0.62]; % [source,head]
a = annotation('textarrow',annotationx,annotationy,'String',['C_' num2str('1')]);
%%
%third plot
ax3=subplot(4,1,3);
plot(ax3,tplot,hitzfplot,'.','linewidth',0.8);
hold on
hold off
set(gca, 'FontName', 'times')
set(gca,'XTick',[0:4:H])
xlabel({'time (\times100us)';'(d)'});
ylabel(['h_' num2str('1') '(t)']);
axis([0,plotuntil,-0.1,1.1]);
%%
%forth plot
ax4=subplot(4,1,4);
plot(ax4,tdmsplot,dhsnoplot,'.',firstsampleposition,yaxisfirstsampleposition,'*','linewidth',2);

set(gca, 'FontName', 'times')
set(gca,'XTick',[0:2:H])
xlabel({'Offset of the window of   \it{k}\rm consecutive jobs ( \times100us)';'(e)'})
ylabel(['m_' num2str('1') '(O,k)'])
axis([0,H,0,3]);
axis 'auto y'
grid on
