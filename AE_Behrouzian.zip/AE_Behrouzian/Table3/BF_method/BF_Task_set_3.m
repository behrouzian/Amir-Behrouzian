%Author: Amir Behrouzian (abehrouzian@gmail.com)
%Table III; Task set number 3; BF method;
%Output: elapse time and maximum number of deadline hit jobs 
%
clear;clc
%INPUT
k=170;         %number of the consecutive samples that should be verified
C=[5,5,7,7,5, 13]; %%Execution time in priority order [high>>>low]
T=[50,50,30,50,30, 57]; %%Period in priority order [high>>>low]
O=[0,12, 19,37,21];  %%offset of the highest=0 and the lowest=unknown
Di=55;   %Deadline of the task with the lowest priority
step=0.001;    %accuracy: defined from the frequency of the processor of the scheduler %1Mhz in this case (the rest of times are in ms)

%------------------------------------------------------------------------------------------------
%-------calculation of the resource accessibility function----------------
SizeC=size(C);
Nht=SizeC(1,2)-1; %(Number of higher priority tasks)number of tasks with priorities higher that the lowest priority task

tic
%%%%%%calculation of the hiperperiod of tasks with higher priority

H=1;
for i=1:(SizeC(1,2)-1);
    H=lcm(H,T(1,i));
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
l=zeros(1,H*(1/step));
numjobinfirsthype=0;
loopcounter=0;
for n=1:Nht
    Numjobfirsthyp=H/T(1,n);
    Nhtloc=n-1;
    
    for i=1:Numjobfirsthyp
        B=O(1,n)+(i-1)*T(1,n);
        numjobinfirsthype=numjobinfirsthype+1; %counter for the number of jobs in total in the first hyperperiod
        %%% calculation of idle till B
        Idle=0;
        for nn=1:B*(1/step)
            if l(1,nn)==0
                Idle=Idle+1;
            end
        end
        Idle=Idle*step;
        
        
        %%% calculation of the response time of the job i of task n
        Con=i*C(1,n)+Idle;
        tnew=Con;    % pronounce it t-old
        told=tnew+1;  %pronounce it t-new
        f=0;  %initialization
        while told~=tnew;
            told=tnew;
            f=0;
            if Nhtloc>0
                for m=1:Nhtloc
                f=f+ceil(((told-O(1,m))/T(1,m)))*C(1,m);
                loopcounter=loopcounter+1;
                end
            end
            tnew=Con+f;
        end
        R=tnew;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        for nnn=1:H*(1/step)
            if B <= (nnn*step) & (nnn*step)<=R
                l(1,nnn)=1;
            end
        end
        
    end
end
l=1-l;      




%---------------------------------------------------------


sizeC=size(C);
sizeT=size(T);
Ti=T(1,sizeT(1,2));          %sampling period of the task with lower priority
Ci=C(1,sizeC(1,2));        %execution time of the the task with lower priority

raf=zeros(1,(H/step));
for i=1:1:H/step;
    mm=i;
    for j=0:1:(Di/step-1);
         mm=mm+1;
         if mm>=(H/step); %for 2 purpose:1. when the inner loop reaches to the end of hyperperiod which "=" works
             %and 2. when i=H/ste
            mm=1;
         end   
         raf(1,i)=raf(1,i)+l(1,mm);

    end
end
raf=raf*step;

hitzf=zeros(1,(H/step));
for i=1:1:H/step;
    if Ci<=raf(1,i);
        hitzf(1,i)=1;
    end
end


%here we determine the number of DM for an offset of ii-1 of the window of
%k release of $\tau_i$ in dimention 2 (to right)
dhno=zeros(1,(H/step));
for i=1:1:H/step;
    for j=1:1:k
        
        hitormiss=hitzf(1,floor(mod(((j-1)*Ti+(i*step)),H)*(1/step)+1));
    dhno(1,i)=dhno(1,i)+hitormiss;
    end
end

%%%%%%%%%Obtaining the maximum number of deadline misses
m1_max=max(dhno)
%---------------------------------------------------------------------------
toc

