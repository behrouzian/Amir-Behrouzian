%Author: Amir Behrouzian (abehrouzian@gmail.com)
%Table III; Task set number 2; FAn method;
%Output: elapse time and maximum number of deadline hit jobs 
%
clear;clc
%%%% INPUT
k=170;         %Number of the consecutive jobs
C=[5,7,11, 16];  %Execution times in priority order [higher priority>>>lower priority]
D=[50,47,29, 55];   %Deadlines of the tasks in priority order [higher priority>>>lower priority]
T=[50,47,29, 57];   %Period in priority order [higher priority>>>lower priority]
O=[0,12, 19];      %Offsets of each task in priority order [higher priority>>>lower priority]. There is no offset decided for the lowest priority task

%------------------------------------------------------------------------------------------------


%%FAn method: phase1: hit-zone formulation

%obtain the accessibility function (paper: Definition.1)
SizeC=size(C);
Nht=SizeC(1,2)-1; %(Number of higher priority tasks)number of tasks with priorities higher that the lowest priority task
tic
%calculation of the hiperperiod of tasks with higher priority
H=1;
for i=1:(SizeC(1,2)-1);
    H=lcm(H,T(1,i));
end
%obtain accessibility function
step=0.5;
l=zeros(1,H*(1/step));  % l: accessibility function
numjobinfirsthype=0; %number of the jobs in the first hyperperiod
loopcounter=0;
for n=1:Nht
    Numjobfirsthyp=H/T(1,n);
    Nhtloc=n-1;
    
    for i=1:Numjobfirsthyp
        B=O(1,n)+(i-1)*T(1,n); % B: commencement of a job execution
        numjobinfirsthype=numjobinfirsthype+1; %counter for the number of jobs in total in the first hyperperiod
        %%% calculation of idle till B
        Idle=0;
        for nn=1:B*(1/step)
            if l(1,nn)==0
                Idle=Idle+1;
            end
        end
        Idle=Idle*step;
        
        
        %%% calculation of the response time of the job i of task n
        Con=i*C(1,n)+Idle;
        tnew=Con;    % pronounce it t-old
        told=tnew+1;  %pronounce it t-new
        f=0;  %initialization
        while told~=tnew;
            told=tnew;
            f=0;
            if Nhtloc>0
                for m=1:Nhtloc
                f=f+ceil(((told-O(1,m))/T(1,m)))*C(1,m);
                loopcounter=loopcounter+1;
                end
            end
            tnew=Con+f;
        end
        R=tnew;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        for nnn=1:H*(1/step)
            if B <= (nnn*step) & (nnn*step)<=R
                l(1,nnn)=1;
            end
        end
        
    end
end
l=1-l;
atfstart2=zeros(1,100);
atfend2=zeros(1,100);
atfstart_counter=0;
atfend_counter=0;
%examine if the begining of a period is atfstart. 
if l(1,1)>l(1,H*(1/step))
    atfstart_counter=atfstart_counter+1;
    atfstart2(1,atfstart_counter)=0;
end
%examine the rest of a period to find atfstart and end
for n=1:(H*(1/step)-1)
    if l(1,n)<l(1,n+1)
        atfstart_counter=atfstart_counter+1;
        atfstart2(1,atfstart_counter)=n*step;
    end
    if l(1,n)>l(1,n+1)
        atfend_counter=atfend_counter+1;
        atfend2(1,atfend_counter)=n*step;
    end
end
%examine if the end of a period is atfend. 
if l(1,1)<l(1,H*(1/step))
    atfend_counter=atfend_counter+1;
    atfend2(1,atfend_counter)=H;
end
atfstart=zeros(1,atfstart_counter);
atfend=zeros(1,atfstart_counter);
for n=1:atfstart_counter
    atfstart(1,n)=atfstart2(1,n);
    atfend(1,n)=atfend2(1,n);
end





SizeT=size(T);
SizeD=size(D);
Ti=T(1,SizeT(1,2));          %sampling period of the task with lower priority
Di=D(1,SizeD(1,2));
Ci=C(1,SizeC(1,2));        %execution time of the the task with lower priority


sizetdmaschedule=size(atfstart);


atf=zeros(1,(H)*(1/step));
for j=1:sizetdmaschedule(1,2);
    for i=1:(H)*(1/step);
        if (mod((i-1)*step,H)>=atfstart(1,j) && mod((i-1)*step,H)<(atfend(1,j)))
        atf(1,i)=1;
        end
    end
end

raf=zeros(1,(H/step));
for i=1:1:H/step;
    for j=0:1:Di/step;
        mm=i+j;
        raf(1,i)=raf(1,i)+atf(1,mod(mm,H/step)+1);
    end
end
raf=raf*step;

hitzf=ones(1,H/step);
for i=1:1:H/step;
    if Ci<=raf(1,i);
        hitzf(1,i)=0;
    end
end


%report the start and end time of the hit zones
hzstarttime2=zeros(1,100);
hzendtime2=zeros(1,100);
hzstarttime_counter=0;
hzendtime_counter=0;
for i=2:1:H/step;
    if hitzf(1,i)<hitzf(1,i-1) && i*step<H; %note that we want to find the begining of HIT-ZONE
        hzstarttime_counter=hzstarttime_counter+1;
        hzstarttime2(1,hzstarttime_counter)=(i-1)*step;
    elseif hitzf(1,i)>hitzf(1,i-1)&& i*step<H;
        hzendtime_counter=hzendtime_counter+1;
        hzendtime2(1,hzendtime_counter)=(i-1)*step;
    end
end
hzstarttime=zeros(1,hzstarttime_counter);
hzendtime=zeros(1,hzendtime_counter);
for i=1:1:hzstarttime_counter;
    hzstarttime(1,i) = hzstarttime2(1,i);
    hzendtime(1,i) = hzendtime2(1,i);
end

%--------------------------------------------------------


dmsno=zeros(1,H/step);
for i=1:H/step;
    for n=1:k
        dmsno(1,i) = dmsno(1,i) + hitzf(1,fix(mod((n*Ti)+(i*step),H)/step)+1);
    end
end




%%FAn method: phase2: compute m1-max(k)
%%%%%%determining the first sample position when one of the sample hit the
%begigning of a miss zone
mzstarttimesize=size(hzstarttime);
mzstarttimeno=mzstarttimesize(1,2);
firstsampleposition=zeros(1,k*mzstarttimeno);
dmsmaxsuspicion=zeros(1,mzstarttimeno*k);
for j=1:mzstarttimeno
    for i=1:k
        firstsampleposition(1,(j-1)*k+i)=mod(hzstarttime(1,j),H)-mod((i-1)*Ti,H);
        if firstsampleposition(1,(j-1)*k+i)<0
            firstsampleposition(1,(j-1)*k+i)=H+firstsampleposition(1,(j-1)*k+i);
        end
        if firstsampleposition(1,(j-1)*k+i)==0 
            dmsmaxsuspicion(1,(j-1)*k+i)=dmsno(1,1); % because the first element is dmsno(1,1)
        else
        dmsmaxsuspicion(1,(j-1)*k+i)=dmsno(1,floor(firstsampleposition(1,(j-1)*k+i)/step));
        end
    end
end

DSMAX=max(dmsmaxsuspicion);
yaxisfirstsampleposition=max(dmsno)*ones(1,k*mzstarttimeno);
yaxisfirstsampleposition=k-yaxisfirstsampleposition;
%---------------------------------------------------------------------------

%here we obtain the candidate for the minimum number of DMs
mzendtimesize=size(hzendtime);
mzendtimeno=mzendtimesize(1,2);
firstsamplepositionformindm=zeros(1,k*mzendtimeno);
dmsminsuspicion=zeros(1,mzendtimeno*k);
for j=1:mzendtimeno
    for i=1:k
        firstsamplepositionformindm(1,(j-1)*k+i)=mod(hzendtime(1,j),H)-mod((i-1)*Ti,H);
        if firstsamplepositionformindm(1,(j-1)*k+i)<0
            firstsamplepositionformindm(1,(j-1)*k+i)=H+firstsamplepositionformindm(1,(j-1)*k+i);
        end
        if firstsamplepositionformindm(1,(j-1)*k+i)==0 
            dmsminsuspicion(1,(j-1)*k+i)=dmsno(1,1); % because the first element is dmsno(1,1)
        else
        dmsminsuspicion(1,(j-1)*k+i)=dmsno(1,floor(firstsamplepositionformindm(1,(j-1)*k+i)/step));
        end
    end
end
DSMIN=min(dmsminsuspicion); %minimum number of deadline miss
m1_max=k-DSMIN  %maximum number of deadline hit
yaxisfirstsamplepositionformindm=max(dmsno)*ones(1,k*mzendtimeno);
yaxisfirstsamplepositionformindm=k-yaxisfirstsamplepositionformindm;
%---------------------------------------------------------------------------
toc






